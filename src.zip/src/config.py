"""Configuration for the object detection pipeline.

Replaces the notebook's hardcoded ``CONFIG`` dict with a dataclass that has
sane relative defaults, plus CLI overrides for anything a user is likely to
change (video source, model paths, output location, thresholds).
"""
import argparse
import os
from dataclasses import dataclass, field
from typing import List, Optional, Union

DEFAULT_CLASSES = [
    "background", "aeroplane", "bicycle", "bird", "boat",
    "bottle", "bus", "car", "cat", "chair", "cow", "diningtable",
    "dog", "horse", "motorbike", "person", "pottedplant", "sheep",
    "sofa", "train", "tvmonitor",
]

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

MODEL_CHOICES = ["mobilenet", "yolov8"]


@dataclass
class Config:
    model: str = "mobilenet"                     # "mobilenet" or "yolov8"

    # MobileNet-SSD (Caffe) specific
    prototxt_path: str = os.path.join(PROJECT_ROOT, "models", "deploy.prototxt.txt")
    model_path: str = os.path.join(PROJECT_ROOT, "models", "mobilenet_iter_73000.caffemodel")
    classes: List[str] = field(default_factory=lambda: list(DEFAULT_CLASSES))

    # YOLOv8 (Ultralytics) specific
    yolo_weights: str = os.path.join(PROJECT_ROOT, "models", "yolov8n.pt")
    device: str = "cpu"

    video_source: Union[int, str] = 0
    max_frames: int = 300
    confidence_threshold: float = 0.5
    output_dir: str = os.path.join(PROJECT_ROOT, "detection_results")
    display_output: bool = True
    save_video: bool = True
    save_csv: bool = True
    log_interval: int = 10
    log_file: str = os.path.join(PROJECT_ROOT, "object_detection.log")

    # ByteTrack multi-object tracking (off by default -- detection-only mode
    # is unaffected by any of these)
    tracking_enabled: bool = False
    track_high_thresh: float = 0.25
    track_low_thresh: float = 0.1
    new_track_thresh: float = 0.25
    track_buffer: int = 30
    match_thresh: float = 0.8
    fuse_score: bool = True

    # Line-crossing counting (off by default -- requires tracking, which is
    # auto-enabled by config_from_args when --count is passed)
    counting_enabled: bool = False
    line_orientation: str = "horizontal"       # "horizontal" or "vertical"
    line_position: float = 0.5                  # fraction of frame height/width, in [0, 1]
    line_in_direction: Optional[str] = None      # None -> orientation's default (see counting/line.py)
    count_classes: Optional[List[str]] = None    # None -> count every class

    def validate_paths(self) -> None:
        if self.model == "mobilenet":
            if not os.path.isfile(self.prototxt_path):
                raise FileNotFoundError(f"Prototxt file not found at {self.prototxt_path}")
            if not os.path.isfile(self.model_path):
                raise FileNotFoundError(f"Model file not found at {self.model_path}")
        # yolo_weights may be a bare name (e.g. "yolov8n.pt") that ultralytics
        # resolves/downloads itself, so it isn't required to already exist on disk.


def _parse_video_source(value: str) -> Union[int, str]:
    """Webcam index (e.g. "0") stays an int; anything else is a file/stream path."""
    try:
        return int(value)
    except ValueError:
        return value


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Real-time object detection (MobileNet-SSD or YOLOv8)")
    parser.add_argument("--model", type=str, default=None, choices=MODEL_CHOICES,
                         help="Detection backend to use (default: mobilenet)")
    parser.add_argument("--source", type=_parse_video_source, default=None,
                         help="Webcam index (e.g. 0) or path to a video file (default: 0)")
    parser.add_argument("--prototxt", type=str, default=None,
                         help="Path to deploy.prototxt.txt (mobilenet only; default: models/deploy.prototxt.txt)")
    parser.add_argument("--weights", type=str, default=None,
                         help="Path to the .caffemodel (mobilenet) or .pt (yolov8) weights file")
    parser.add_argument("--device", type=str, default=None,
                         help="Inference device for yolov8, e.g. 'cpu' or '0' (default: cpu)")
    parser.add_argument("--output-dir", type=str, default=None,
                         help="Directory for output video/CSV/summary (default: detection_results)")
    parser.add_argument("--max-frames", type=int, default=None,
                         help="Stop after N frames, 0 = unlimited (default: 300)")
    parser.add_argument("--confidence", type=float, default=None,
                         help="Minimum confidence to keep a detection (default: 0.5)")
    parser.add_argument("--log-interval", type=int, default=None,
                         help="Log a summary line every N frames (default: 10)")
    parser.add_argument("--log-file", type=str, default=None,
                         help="Path to the log file (default: object_detection.log)")
    parser.add_argument("--no-display", action="store_true", help="Disable the cv2.imshow preview window")
    parser.add_argument("--no-video", action="store_true", help="Do not save an annotated output video")
    parser.add_argument("--no-csv", action="store_true", help="Do not save the per-frame detection CSV")

    parser.add_argument("--track", action="store_true",
                         help="Enable ByteTrack multi-object tracking on top of detections "
                              "(tested with --model yolov8; detection-only mode is the default)")
    parser.add_argument("--track-buffer", type=int, default=None,
                         help="Frames to keep a lost track alive before dropping it (default: 30)")
    parser.add_argument("--track-high-thresh", type=float, default=None,
                         help="Confidence threshold for first-stage track association (default: 0.25)")
    parser.add_argument("--match-thresh", type=float, default=None,
                         help="IoU/cost threshold for track association (default: 0.8)")

    parser.add_argument("--count", action="store_true",
                         help="Enable line-crossing counting on top of tracking (implies --track)")
    parser.add_argument("--line-orientation", choices=["horizontal", "vertical"], default=None,
                         help="Counting line orientation (default: horizontal)")
    parser.add_argument("--line-position", type=float, default=None,
                         help="Line position as a fraction of frame height/width, 0-1 (default: 0.5)")
    parser.add_argument("--in-direction", choices=["down", "up", "left", "right"], default=None,
                         help="Crossing direction counted as IN (default: down for horizontal, "
                              "right for vertical)")
    parser.add_argument("--count-classes", nargs="+", default=None,
                         help="Only count these class names crossing the line, e.g. person car "
                              "(default: count every class)")
    return parser


def config_from_args(args=None) -> Config:
    parser = build_arg_parser()
    ns = parser.parse_args(args=args)

    cfg = Config()
    if ns.model:
        cfg.model = ns.model
    if ns.source is not None:
        cfg.video_source = ns.source
    if ns.prototxt:
        cfg.prototxt_path = ns.prototxt
    if ns.weights:
        if cfg.model == "yolov8":
            cfg.yolo_weights = ns.weights
        else:
            cfg.model_path = ns.weights
    if ns.device:
        cfg.device = ns.device
    if ns.output_dir:
        cfg.output_dir = ns.output_dir
    if ns.max_frames is not None:
        cfg.max_frames = ns.max_frames
    if ns.confidence is not None:
        cfg.confidence_threshold = ns.confidence
    if ns.log_interval is not None:
        cfg.log_interval = ns.log_interval
    if ns.log_file:
        cfg.log_file = ns.log_file
    if ns.no_display:
        cfg.display_output = False
    if ns.no_video:
        cfg.save_video = False
    if ns.no_csv:
        cfg.save_csv = False
    if ns.track:
        cfg.tracking_enabled = True
    if ns.track_buffer is not None:
        cfg.track_buffer = ns.track_buffer
    if ns.track_high_thresh is not None:
        cfg.track_high_thresh = ns.track_high_thresh
    if ns.match_thresh is not None:
        cfg.match_thresh = ns.match_thresh
    if ns.count:
        cfg.counting_enabled = True
        cfg.tracking_enabled = True  # counting requires persistent track IDs
    if ns.line_orientation:
        cfg.line_orientation = ns.line_orientation
    if ns.line_position is not None:
        cfg.line_position = ns.line_position
    if ns.in_direction:
        cfg.line_in_direction = ns.in_direction
    if ns.count_classes:
        cfg.count_classes = ns.count_classes
    return cfg
