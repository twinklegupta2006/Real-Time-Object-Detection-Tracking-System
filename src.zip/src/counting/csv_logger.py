"""Per-crossing-event CSV logging -- a separate file from both the
detection-only and tracking CSVs; it only gets a row when a crossing event
actually happens, not one per frame."""
import csv
import os

from .counter import CrossingEvent


class CountingEventCSVLogger:
    FIELDNAMES = ["frame", "timestamp", "track_id", "class_name", "direction", "crossing_position"]

    def __init__(self, csv_path: str):
        self.csv_path = csv_path
        parent = os.path.dirname(csv_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self._file = open(csv_path, "w", newline="")
        self._writer = csv.DictWriter(self._file, fieldnames=self.FIELDNAMES)
        self._writer.writeheader()

    def log_event(self, event: CrossingEvent) -> None:
        self._writer.writerow({
            "frame": event.frame,
            "timestamp": event.timestamp,
            "track_id": event.track_id,
            "class_name": event.class_name,
            "direction": event.direction,
            "crossing_position": round(float(event.crossing_position), 2),
        })

    def close(self) -> None:
        if self._file and not self._file.closed:
            self._file.close()

    def __enter__(self) -> "CountingEventCSVLogger":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
