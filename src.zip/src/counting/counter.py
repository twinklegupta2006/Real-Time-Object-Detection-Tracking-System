"""Line-crossing counter: tracks each track's previous position and detects
when it crosses a configured line, counting each track at most once per
direction ("in"/"out"). Operates purely on TrackedObject data (Phase 4's
tracker output) -- no knowledge of detectors or ByteTrack internals.
"""
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Set

from ..tracking.base import TrackedObject
from .line import CountingLine


@dataclass
class CrossingEvent:
    frame: int
    timestamp: float
    track_id: int
    class_name: str
    direction: str  # "in" or "out"
    crossing_position: float


class LineCrossingCounter:
    def __init__(self, line: CountingLine, count_classes: Optional[List[str]] = None):
        self.line = line
        self.count_classes = set(count_classes) if count_classes else None

        self._last_coordinate: Dict[int, float] = {}
        self._counted_directions: Dict[int, Set[str]] = {}
        self._seen_track_ids: Set[int] = set()

        self.total_in = 0
        self.total_out = 0
        self.counts_by_class: Dict[str, Dict[str, int]] = {}
        self.events: List[CrossingEvent] = []

    def _is_countable(self, class_name: str) -> bool:
        return self.count_classes is None or class_name in self.count_classes

    def _movement_direction(self, delta: float) -> str:
        if self.line.orientation == "horizontal":
            return "down" if delta > 0 else "up"
        return "right" if delta > 0 else "left"

    def update(self, tracked_objects: List[TrackedObject], frame_width: int, frame_height: int,
               frame_number: int, timestamp: Optional[float] = None) -> List[CrossingEvent]:
        if timestamp is None:
            timestamp = time.time()

        line_pixel = self.line.pixel_position(frame_width, frame_height)
        new_events: List[CrossingEvent] = []

        for obj in tracked_objects:
            self._seen_track_ids.add(obj.track_id)

            coord = self.line.coordinate_of(obj.x1, obj.y1, obj.x2, obj.y2)
            prev_coord = self._last_coordinate.get(obj.track_id)
            self._last_coordinate[obj.track_id] = coord

            if not self._is_countable(obj.class_name):
                continue
            if prev_coord is None:
                continue  # first time seeing this track; nothing to compare yet

            prev_side = prev_coord - line_pixel
            curr_side = coord - line_pixel
            if prev_side == 0 or curr_side == 0 or (prev_side > 0) == (curr_side > 0):
                continue  # same side as before -> no crossing

            direction = "in" if self._movement_direction(coord - prev_coord) == self.line.in_direction else "out"

            already_counted = self._counted_directions.setdefault(obj.track_id, set())
            if direction in already_counted:
                continue  # this track already counted for this direction
            already_counted.add(direction)

            if direction == "in":
                self.total_in += 1
            else:
                self.total_out += 1
            class_counts = self.counts_by_class.setdefault(obj.class_name, {"in": 0, "out": 0})
            class_counts[direction] += 1

            event = CrossingEvent(
                frame=frame_number, timestamp=timestamp, track_id=obj.track_id,
                class_name=obj.class_name, direction=direction, crossing_position=coord,
            )
            self.events.append(event)
            new_events.append(event)

        return new_events

    @property
    def unique_track_count(self) -> int:
        return len(self._seen_track_ids)
