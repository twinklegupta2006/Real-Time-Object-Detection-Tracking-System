"""Counting-line representation: a horizontal or vertical line, positioned
as a fraction of the frame so it stays resolution-independent, plus which
crossing direction counts as "in"."""
from dataclasses import dataclass

VALID_ORIENTATIONS = ("horizontal", "vertical")
VALID_DIRECTIONS_BY_ORIENTATION = {
    "horizontal": ("down", "up"),
    "vertical": ("left", "right"),
}


@dataclass
class CountingLine:
    orientation: str   # "horizontal" or "vertical"
    position: float    # fraction of frame height (horizontal) or width (vertical), in [0, 1]
    in_direction: str  # the crossing direction counted as "in"

    def __post_init__(self) -> None:
        if self.orientation not in VALID_ORIENTATIONS:
            raise ValueError(f"orientation must be one of {VALID_ORIENTATIONS}, got {self.orientation!r}")
        if not (0.0 <= self.position <= 1.0):
            raise ValueError(f"position must be within [0, 1], got {self.position!r}")
        valid_directions = VALID_DIRECTIONS_BY_ORIENTATION[self.orientation]
        if self.in_direction not in valid_directions:
            raise ValueError(
                f"in_direction must be one of {valid_directions} for a {self.orientation} line, "
                f"got {self.in_direction!r}"
            )

    def pixel_position(self, frame_width: int, frame_height: int) -> float:
        return self.position * (frame_height if self.orientation == "horizontal" else frame_width)

    def coordinate_of(self, x1: float, y1: float, x2: float, y2: float) -> float:
        """The box-centroid coordinate relevant to this line's orientation."""
        return (y1 + y2) / 2 if self.orientation == "horizontal" else (x1 + x2) / 2


def default_in_direction(orientation: str) -> str:
    return "down" if orientation == "horizontal" else "right"
