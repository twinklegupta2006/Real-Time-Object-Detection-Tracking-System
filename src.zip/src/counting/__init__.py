"""Line-crossing counting, built on top of tracking (src/tracking) -- has no
knowledge of detectors or ByteTrack internals, only of TrackedObject."""
from ..config import Config
from .counter import CrossingEvent, LineCrossingCounter
from .line import CountingLine, default_in_direction

__all__ = ["CountingLine", "CrossingEvent", "LineCrossingCounter", "create_counter"]


def create_counter(config: Config) -> LineCrossingCounter:
    in_direction = config.line_in_direction or default_in_direction(config.line_orientation)
    line = CountingLine(
        orientation=config.line_orientation,
        position=config.line_position,
        in_direction=in_direction,
    )
    return LineCrossingCounter(line, count_classes=config.count_classes)
