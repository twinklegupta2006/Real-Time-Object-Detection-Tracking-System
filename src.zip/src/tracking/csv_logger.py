"""Per-frame tracking CSV logging -- a separate schema/file from the
detection-only CSV (src/csv_logger.py), which is left untouched so
detection-only mode's output format never changes."""
import csv
import os
from typing import Tuple


class TrackingCSVLogger:
    FIELDNAMES = ["frame", "timestamp", "track_id", "class_id", "class_name", "confidence", "x1", "y1", "x2", "y2"]

    def __init__(self, csv_path: str):
        self.csv_path = csv_path
        parent = os.path.dirname(csv_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self._file = open(csv_path, "w", newline="")
        self._writer = csv.DictWriter(self._file, fieldnames=self.FIELDNAMES)
        self._writer.writeheader()

    def log_track(self, frame: int, timestamp: float, track_id: int, class_id: int, class_name: str,
                  confidence: float, box: Tuple[int, int, int, int]) -> None:
        x1, y1, x2, y2 = box
        self._writer.writerow({
            "frame": frame,
            "timestamp": timestamp,
            "track_id": track_id,
            "class_id": class_id,
            "class_name": class_name,
            "confidence": round(float(confidence), 4),
            "x1": int(x1),
            "y1": int(y1),
            "x2": int(x2),
            "y2": int(y2),
        })

    def close(self) -> None:
        if self._file and not self._file.closed:
            self._file.close()

    def __enter__(self) -> "TrackingCSVLogger":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
