"""Tracking backends behind a common interface (see base.TrackedObject / base.BaseTracker)."""
from ..config import Config
from .base import BaseTracker, TrackedObject

__all__ = ["BaseTracker", "TrackedObject", "create_tracker"]


def create_tracker(config: Config) -> BaseTracker:
    """Build the tracker backend. Only ByteTrack is supported so far."""
    from .bytetrack_tracker import ByteTrackTracker
    return ByteTrackTracker(
        track_high_thresh=config.track_high_thresh,
        track_low_thresh=config.track_low_thresh,
        new_track_thresh=config.new_track_thresh,
        track_buffer=config.track_buffer,
        match_thresh=config.match_thresh,
        fuse_score=config.fuse_score,
    )
