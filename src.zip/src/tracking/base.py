"""Common tracker interface, analogous to detectors.base.BaseDetector.

A tracker consumes one frame's ``Detection`` list (the same objects
``BaseDetector.detect()`` returns) and returns ``TrackedObject`` instances
carrying a persistent ``track_id`` on top of the usual box/class/confidence
fields. Tracking-specific logic lives entirely here and in the concrete
tracker implementations -- detector classes never know tracking exists.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional

import numpy as np

from ..detectors.base import Detection


@dataclass
class TrackedObject:
    track_id: int
    class_id: int
    class_name: str
    confidence: float
    x1: float
    y1: float
    x2: float
    y2: float


class BaseTracker(ABC):
    @abstractmethod
    def update(self, detections: List[Detection], frame: Optional[np.ndarray] = None) -> List[TrackedObject]:
        """Update tracker state with this frame's detections; return the
        currently active tracked objects (not necessarily one per input
        detection -- a track may persist briefly without a new detection,
        and a brand new detection may not be reported until confirmed)."""
        raise NotImplementedError

    def reset(self) -> None:
        """Clear all internal track state, e.g. before starting a new video."""
        pass
