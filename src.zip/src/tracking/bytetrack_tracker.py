"""ByteTrack tracker, built on ``ultralytics.trackers.byte_tracker.BYTETracker``
(already part of the ``ultralytics`` dependency added in Phase 2 -- this
avoids adding a separate, harder-to-build ``bytetrack``/``cython_bbox``
dependency). ByteTrack itself needs ``lap`` (linear assignment solver, has
a prebuilt wheel, pinned in requirements.txt).

``BYTETracker.update()`` expects a "results-like" object exposing
``.xywh``/``.conf``/``.cls`` arrays with boolean indexing and ``len()``
support (confirmed from its source: ``_split_detections``, ``init_track``,
``parse_bboxes``) -- the ``_DetectionArray`` adapter below is exactly that,
built fresh from our detector-agnostic ``Detection`` list each frame.
"""
import logging
from types import SimpleNamespace
from typing import Dict, List, Optional

import numpy as np

from ..detectors.base import Detection
from .base import BaseTracker, TrackedObject

logger = logging.getLogger(__name__)


class _DetectionArray:
    """Minimal results-like adapter BYTETracker.update() can consume."""

    def __init__(self, xywh: np.ndarray, conf: np.ndarray, cls: np.ndarray):
        self.xywh = xywh
        self.conf = conf
        self.cls = cls

    def __len__(self) -> int:
        return len(self.conf)

    def __getitem__(self, mask) -> "_DetectionArray":
        return _DetectionArray(self.xywh[mask], self.conf[mask], self.cls[mask])


def detections_to_array(detections: List[Detection]) -> _DetectionArray:
    """Convert our common Detection list into the xywh/conf/cls arrays
    BYTETracker.update() expects."""
    if not detections:
        return _DetectionArray(
            np.zeros((0, 4), dtype=np.float32),
            np.zeros((0,), dtype=np.float32),
            np.zeros((0,), dtype=np.float32),
        )

    xywh = np.array(
        [[(d.x1 + d.x2) / 2, (d.y1 + d.y2) / 2, d.x2 - d.x1, d.y2 - d.y1] for d in detections],
        dtype=np.float32,
    )
    conf = np.array([d.confidence for d in detections], dtype=np.float32)
    cls = np.array([float(d.class_id) for d in detections], dtype=np.float32)
    return _DetectionArray(xywh, conf, cls)


def rows_to_tracked_objects(rows: np.ndarray, class_names: Dict[int, str]) -> List[TrackedObject]:
    """Convert BYTETracker.update()'s output rows
    (x1, y1, x2, y2, track_id, score, cls, idx) into TrackedObject instances."""
    tracked: List[TrackedObject] = []
    for row in rows:
        x1, y1, x2, y2, track_id, score, cls = row[:7]
        class_id = int(cls)
        tracked.append(TrackedObject(
            track_id=int(track_id),
            class_id=class_id,
            class_name=class_names.get(class_id, str(class_id)),
            confidence=float(score),
            x1=float(x1), y1=float(y1), x2=float(x2), y2=float(y2),
        ))
    return tracked


class ByteTrackTracker(BaseTracker):
    def __init__(self, track_high_thresh: float = 0.25, track_low_thresh: float = 0.1,
                 new_track_thresh: float = 0.25, track_buffer: int = 30,
                 match_thresh: float = 0.8, fuse_score: bool = True):
        from ultralytics.trackers.byte_tracker import BYTETracker

        args = SimpleNamespace(
            track_high_thresh=track_high_thresh,
            track_low_thresh=track_low_thresh,
            new_track_thresh=new_track_thresh,
            track_buffer=track_buffer,
            match_thresh=match_thresh,
            fuse_score=fuse_score,
        )
        logger.info("Initializing ByteTrack tracker...")
        self._tracker = BYTETracker(args)
        self._class_names: Dict[int, str] = {}

    def update(self, detections: List[Detection], frame: Optional[np.ndarray] = None) -> List[TrackedObject]:
        self._class_names.update({d.class_id: d.class_name for d in detections})
        results = detections_to_array(detections)
        rows = self._tracker.update(results, img=frame)
        return rows_to_tracked_objects(rows, self._class_names)

    def reset(self) -> None:
        self._tracker.reset()
