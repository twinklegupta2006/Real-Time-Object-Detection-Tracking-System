"""Detector-agnostic pipeline: video capture, drawing, CSV logging, video
output, and the summary report.

This is the same capture/drawing/logging logic as Phase 1's ``ObjectDetector``
(identical box-clamping, coloring, overlay, CSV, and report code), except it
now delegates inference to any ``BaseDetector`` instead of owning a Caffe
network directly, so the same pipeline runs both MobileNet-SSD and YOLOv8.
"""
import logging
import os
import time
from datetime import datetime
from typing import Optional, Tuple

import cv2
import numpy as np

from .config import Config
from .counting.counter import LineCrossingCounter
from .counting.csv_logger import CountingEventCSVLogger
from .csv_logger import DetectionCSVLogger
from .detectors.base import BaseDetector
from .tracking.base import BaseTracker
from .tracking.csv_logger import TrackingCSVLogger
from .utils import clamp_box, compute_fps, get_color, is_valid_box

logger = logging.getLogger(__name__)


class ObjectDetectionPipeline:
    def __init__(self, detector: BaseDetector, config: Config, tracker: Optional[BaseTracker] = None,
                 counter: Optional[LineCrossingCounter] = None):
        if counter is not None and tracker is None:
            raise ValueError("Counting requires tracking to be enabled (pass a tracker).")

        self.detector = detector
        self.tracker = tracker
        self.counter = counter
        self.config = config
        os.makedirs(self.config.output_dir, exist_ok=True)

        self.cap = self._initialize_video_source()

        self.output_writer: Optional[cv2.VideoWriter] = None
        self.csv_logger = None  # DetectionCSVLogger or TrackingCSVLogger, depending on self.tracker
        self.counting_csv_logger: Optional[CountingEventCSVLogger] = None
        self.frame_count = 0
        self.start_time = time.time()
        self.object_log = []

    def _initialize_video_source(self) -> cv2.VideoCapture:
        logger.info(f"Opening video source: {self.config.video_source!r}")
        cap = cv2.VideoCapture(self.config.video_source)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open video source: {self.config.video_source!r}")
        return cap

    def _setup_output_video(self) -> str:
        frame_width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or 640
        frame_height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or 480
        fps = self.cap.get(cv2.CAP_PROP_FPS) or 20.0

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = os.path.join(self.config.output_dir, f"detection_{timestamp}.avi")

        fourcc = cv2.VideoWriter_fourcc(*"XVID")
        self.output_writer = cv2.VideoWriter(output_path, fourcc, fps, (frame_width, frame_height))
        logger.info(f"Output video will be saved to: {output_path}")
        return output_path

    def _setup_csv_logger(self) -> str:
        if self.tracker is not None:
            csv_path = os.path.join(self.config.output_dir, "tracking_log.csv")
            self.csv_logger = TrackingCSVLogger(csv_path)
            logger.info(f"Per-frame tracked objects will be logged to: {csv_path}")
        else:
            csv_path = os.path.join(self.config.output_dir, "detection_log.csv")
            self.csv_logger = DetectionCSVLogger(csv_path)
            logger.info(f"Per-frame detections will be logged to: {csv_path}")
        return csv_path

    def _setup_counting_csv_logger(self) -> str:
        csv_path = os.path.join(self.config.output_dir, "counting_events.csv")
        self.counting_csv_logger = CountingEventCSVLogger(csv_path)
        logger.info(f"Counting events will be logged to: {csv_path}")
        return csv_path

    def process_frame(self, frame: np.ndarray) -> Tuple[np.ndarray, dict]:
        self.frame_count += 1
        object_counts: dict = {}
        frame_timestamp = time.time()

        detections = self.detector.detect(frame)

        if self.tracker is not None:
            tracked_objects = self.tracker.update(detections, frame)
            self._draw_and_log_tracked(frame, tracked_objects, frame_timestamp, object_counts)

            if self.counter is not None:
                events = self.counter.update(
                    tracked_objects, frame.shape[1], frame.shape[0], self.frame_count, frame_timestamp
                )
                if self.counting_csv_logger is not None:
                    for event in events:
                        self.counting_csv_logger.log_event(event)
                self._draw_counting_overlay(frame)
        else:
            self._draw_and_log_detections(frame, detections, frame_timestamp, object_counts)

        if self.frame_count % self.config.log_interval == 0:
            logger.info(f"Frame {self.frame_count} - Detected objects: {object_counts}")

        self.object_log.append({
            "frame": self.frame_count,
            "timestamp": frame_timestamp,
            "objects": object_counts,
        })
        self._add_info_overlay(frame, object_counts)
        return frame, object_counts

    def _draw_and_log_detections(self, frame: np.ndarray, detections, frame_timestamp: float,
                                  object_counts: dict) -> None:
        """Detection-only path -- unchanged from Phase 2/3."""
        for det in detections:
            object_counts[det.class_name] = object_counts.get(det.class_name, 0) + 1

            x1, y1, x2, y2 = clamp_box(det.x1, det.y1, det.x2, det.y2,
                                        frame_width=frame.shape[1], frame_height=frame.shape[0])
            if not is_valid_box(x1, y1, x2, y2):
                continue

            color = get_color(det.class_name)
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            text = f"{det.class_name}: {det.confidence * 100:.1f}%"
            text_y = y1 - 10 if y1 > 20 else y1 + 20
            cv2.putText(frame, text, (x1, text_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

            if self.csv_logger is not None:
                self.csv_logger.log_detection(
                    self.frame_count, frame_timestamp, det.class_name, det.confidence, (x1, y1, x2, y2)
                )

    def _draw_and_log_tracked(self, frame: np.ndarray, tracked_objects, frame_timestamp: float,
                               object_counts: dict) -> None:
        for obj in tracked_objects:
            object_counts[obj.class_name] = object_counts.get(obj.class_name, 0) + 1

            x1, y1, x2, y2 = clamp_box(obj.x1, obj.y1, obj.x2, obj.y2,
                                        frame_width=frame.shape[1], frame_height=frame.shape[0])
            if not is_valid_box(x1, y1, x2, y2):
                continue

            color = get_color(obj.class_name)
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            text = f"ID {obj.track_id} {obj.class_name}: {obj.confidence * 100:.1f}%"
            text_y = y1 - 10 if y1 > 20 else y1 + 20
            cv2.putText(frame, text, (x1, text_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

            if self.csv_logger is not None:
                self.csv_logger.log_track(
                    self.frame_count, frame_timestamp, obj.track_id, obj.class_id, obj.class_name,
                    obj.confidence, (x1, y1, x2, y2)
                )

    def _add_info_overlay(self, frame: np.ndarray, object_counts: dict) -> None:
        elapsed = time.time() - self.start_time
        fps = compute_fps(self.frame_count, elapsed)
        status = f"Frame: {self.frame_count} | FPS: {fps:.1f}"
        cv2.putText(frame, status, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        y_offset = 60
        for obj, count in object_counts.items():
            cv2.putText(frame, f"{obj}: {count}", (10, y_offset),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
            y_offset += 30

    def _draw_counting_overlay(self, frame: np.ndarray) -> None:
        height, width = frame.shape[:2]
        line_pixel = int(self.counter.line.pixel_position(width, height))

        if self.counter.line.orientation == "horizontal":
            cv2.line(frame, (0, line_pixel), (width, line_pixel), (255, 255, 0), 2)
        else:
            cv2.line(frame, (line_pixel, 0), (line_pixel, height), (255, 255, 0), 2)

        text = f"IN: {self.counter.total_in}  OUT: {self.counter.total_out}"
        cv2.putText(frame, text, (10, height - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)

    def run(self) -> Tuple[Optional[str], Optional[str]]:
        logger.info("Starting object detection system")
        video_path = self._setup_output_video() if self.config.save_video else None
        csv_path = self._setup_csv_logger() if self.config.save_csv else None
        if self.counter is not None and self.config.save_csv:
            self._setup_counting_csv_logger()
        reading_from_file = isinstance(self.config.video_source, str)

        try:
            while True:
                ret, frame = self.cap.read()
                if not ret:
                    if reading_from_file:
                        logger.info("End of video file reached")
                        break
                    logger.warning("Frame capture error, skipping...")
                    continue

                processed_frame, _ = self.process_frame(frame)

                if self.output_writer is not None:
                    self.output_writer.write(processed_frame)

                if self.config.display_output:
                    cv2.imshow("Object Detection", processed_frame)
                    cv2.waitKey(1)

                if self.config.max_frames > 0 and self.frame_count >= self.config.max_frames:
                    logger.info(f"Reached max frames limit ({self.config.max_frames})")
                    break

        except KeyboardInterrupt:
            logger.info("Interrupted by user")
        except Exception as exc:
            logger.error(f"Processing error: {exc}")
        finally:
            self._cleanup()
            self._generate_report(video_path, csv_path)

        return video_path, csv_path

    def _cleanup(self) -> None:
        logger.info("Cleaning up resources...")
        self.cap.release()
        if self.output_writer:
            self.output_writer.release()
        if self.csv_logger:
            self.csv_logger.close()
        if self.counting_csv_logger:
            self.counting_csv_logger.close()
        if self.config.display_output:
            cv2.destroyAllWindows()

    def _generate_report(self, video_path: Optional[str], csv_path: Optional[str]) -> None:
        logger.info("Generating detection report...")
        elapsed = time.time() - self.start_time
        fps = compute_fps(self.frame_count, elapsed)

        report_path = os.path.join(self.config.output_dir, "detection_summary.txt")
        with open(report_path, "w") as f:
            f.write("Object Detection Report\n")
            f.write(f"Model: {self.config.model}\n")
            f.write(f"Tracking: {'enabled (ByteTrack)' if self.tracker is not None else 'disabled'}\n")
            f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total frames processed: {self.frame_count}\n")
            f.write(f"Processing time: {elapsed:.2f} seconds\n")
            f.write(f"Average FPS: {fps:.1f}\n")

            if video_path:
                f.write(f"\nOutput video: {video_path}\n")
            if csv_path:
                f.write(f"Per-frame CSV log: {csv_path}\n")

            f.write("\nObject Detection Summary:\n")
            total_counts: dict = {}
            for entry in self.object_log:
                for obj, count in entry["objects"].items():
                    total_counts[obj] = total_counts.get(obj, 0) + count

            for obj, count in sorted(total_counts.items()):
                f.write(f"{obj}: {count} detections\n")

            if self.counter is not None:
                f.write("\nCounting Summary:\n")
                f.write(f"Total IN: {self.counter.total_in}\n")
                f.write(f"Total OUT: {self.counter.total_out}\n")
                f.write(f"Unique tracks observed: {self.counter.unique_track_count}\n")
                f.write(f"Crossing events: {len(self.counter.events)}\n")
                if self.counting_csv_logger is not None:
                    f.write(f"Counting event log: {self.counting_csv_logger.csv_path}\n")
                f.write("Counts by class (in/out):\n")
                for class_name, counts in sorted(self.counter.counts_by_class.items()):
                    f.write(f"  {class_name}: in={counts['in']} out={counts['out']}\n")

        logger.info(f"Report saved to {report_path}")
        logger.info("Processing complete")
