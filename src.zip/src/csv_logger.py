"""Per-frame detection CSV logging.

The original README advertised a ``detection_log.csv`` with a per-frame
detection log, but the notebook never wrote one. This implements it: one row
per detected object (tagged with its frame number), which is more useful for
downstream analysis than one aggregate row per frame.
"""
import csv
import os
from typing import Tuple


class DetectionCSVLogger:
    FIELDNAMES = ["frame", "timestamp", "label", "confidence", "x1", "y1", "x2", "y2"]

    def __init__(self, csv_path: str):
        self.csv_path = csv_path
        parent = os.path.dirname(csv_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self._file = open(csv_path, "w", newline="")
        self._writer = csv.DictWriter(self._file, fieldnames=self.FIELDNAMES)
        self._writer.writeheader()

    def log_detection(self, frame: int, timestamp: float, label: str,
                       confidence: float, box: Tuple[int, int, int, int]) -> None:
        x1, y1, x2, y2 = box
        self._writer.writerow({
            "frame": frame,
            "timestamp": timestamp,
            "label": label,
            "confidence": round(float(confidence), 4),
            "x1": int(x1),
            "y1": int(y1),
            "x2": int(x2),
            "y2": int(y2),
        })

    def close(self) -> None:
        if self._file and not self._file.closed:
            self._file.close()

    def __enter__(self) -> "DetectionCSVLogger":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
