"""Orchestration logic shared by the Streamlit app and its smoke test.

Builds a ``Config`` from simple parameters and runs the existing pipeline
(``create_detector`` / ``create_tracker`` / ``create_counter`` /
``ObjectDetectionPipeline`` from Phases 1-5) completely unchanged. Contains
no Streamlit import and no UI code -- ``streamlit_app.py`` is the only place
that talks to Streamlit, and none of ``src/detectors``, ``src/tracking``,
``src/counting``, or ``src/pipeline`` know this module exists.
"""
import os
import subprocess
from dataclasses import dataclass
from typing import List, Optional

import cv2

from .config import DEFAULT_CLASSES, Config
from .counting import create_counter
from .detectors import create_detector
from .pipeline import ObjectDetectionPipeline
from .tracking import create_tracker

MODEL_LABELS = {"YOLOv8n": "yolov8", "MobileNet-SSD": "mobilenet"}
VOC_CLASSES = [c for c in DEFAULT_CLASSES if c != "background"]

# The standard 80-class COCO label set, in the order YOLOv8n's pretrained
# weights use (this is a fixed, well-known list -- not something the model
# needs to be loaded to know, so the UI can populate a class picker before
# any model is loaded).
COCO_CLASSES = [
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat",
    "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog",
    "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella",
    "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite",
    "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle",
    "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich",
    "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch",
    "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse", "remote",
    "keyboard", "cell phone", "microwave", "oven", "toaster", "sink", "refrigerator", "book",
    "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush",
]


class AppConfigError(ValueError):
    """A user-facing configuration problem: bad parameters, missing weights,
    an unplayable video, etc. Distinguished from unexpected internal errors
    so the UI can show a clear message instead of a raw traceback."""


@dataclass
class RunResult:
    video_path: Optional[str]
    preview_video_path: Optional[str]  # browser-playable H.264 copy, if conversion succeeded
    csv_path: Optional[str]
    counting_csv_path: Optional[str]
    summary_path: str
    summary_text: str


def _validate_video_file(path: str) -> None:
    if not os.path.isfile(path):
        raise AppConfigError(f"Video file not found: {path}")
    cap = cv2.VideoCapture(path)
    opened = cap.isOpened()
    cap.release()
    if not opened:
        raise AppConfigError(
            f"Could not open '{os.path.basename(path)}' as a video -- "
            "it may be corrupted or in an unsupported format."
        )


def make_browser_preview_copy(video_path: str) -> Optional[str]:
    """Best-effort H.264/mp4 copy of the pipeline's (XVID/.avi) output, for
    in-browser preview via st.video(). Uses the portable ffmpeg binary
    bundled by imageio-ffmpeg (not a system dependency). Returns None if the
    conversion isn't available or fails -- callers should fall back to
    offering the original file for download, not treat this as fatal.
    """
    try:
        import imageio_ffmpeg
    except ImportError:
        return None

    preview_path = os.path.splitext(video_path)[0] + "_preview.mp4"
    try:
        ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
        result = subprocess.run(
            [ffmpeg_exe, "-y", "-i", video_path, "-vcodec", "libx264",
             "-pix_fmt", "yuv420p", "-movflags", "+faststart", preview_path],
            capture_output=True, text=True, timeout=300,
        )
    except Exception:
        return None

    if result.returncode != 0 or not os.path.isfile(preview_path):
        return None
    return preview_path


def run_pipeline(
    source_video_path: str,
    model: str,
    enable_tracking: bool = False,
    enable_counting: bool = False,
    confidence: float = 0.5,
    max_frames: int = 0,
    output_dir: str = "detection_results",
    line_orientation: str = "horizontal",
    line_position: float = 0.5,
    in_direction: Optional[str] = None,
    count_classes: Optional[List[str]] = None,
    device: str = "cpu",
    make_preview: bool = True,
) -> RunResult:
    if model not in ("mobilenet", "yolov8"):
        raise AppConfigError(f"Unsupported model: {model!r} (expected 'mobilenet' or 'yolov8')")

    _validate_video_file(source_video_path)

    if enable_counting and not enable_tracking:
        enable_tracking = True  # counting requires tracking, same as the CLI's --count

    cfg = Config(
        model=model,
        video_source=source_video_path,
        confidence_threshold=confidence,
        max_frames=max_frames,
        output_dir=output_dir,
        display_output=False,  # never open a cv2 preview window from a web app
        device=device,
        tracking_enabled=enable_tracking,
        counting_enabled=enable_counting,
        line_orientation=line_orientation,
        line_position=line_position,
        line_in_direction=in_direction,
        count_classes=count_classes or None,
    )

    try:
        cfg.validate_paths()
    except FileNotFoundError as exc:
        raise AppConfigError(str(exc)) from exc

    try:
        detector = create_detector(cfg)
    except ValueError as exc:
        raise AppConfigError(str(exc)) from exc

    tracker = create_tracker(cfg) if cfg.tracking_enabled else None

    counter = None
    if cfg.counting_enabled:
        try:
            counter = create_counter(cfg)
        except ValueError as exc:
            raise AppConfigError(f"Invalid counting line configuration: {exc}") from exc

    try:
        pipeline = ObjectDetectionPipeline(detector, cfg, tracker=tracker, counter=counter)
    except ValueError as exc:
        raise AppConfigError(str(exc)) from exc

    video_path, csv_path = pipeline.run()

    summary_path = os.path.join(cfg.output_dir, "detection_summary.txt")
    with open(summary_path) as f:
        summary_text = f.read()

    counting_csv_path = None
    if cfg.counting_enabled:
        candidate = os.path.join(cfg.output_dir, "counting_events.csv")
        if os.path.isfile(candidate):
            counting_csv_path = candidate

    preview_video_path = None
    if make_preview and video_path and os.path.isfile(video_path):
        preview_video_path = make_browser_preview_copy(video_path)

    return RunResult(
        video_path=video_path,
        preview_video_path=preview_video_path,
        csv_path=csv_path,
        counting_csv_path=counting_csv_path,
        summary_path=summary_path,
        summary_text=summary_text,
    )
