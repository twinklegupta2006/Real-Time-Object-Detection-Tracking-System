"""MobileNet-SSD detector (Caffe, via OpenCV DNN).

Same model and inference logic used in Phase 1 (identical blob parameters
and output-tensor parsing), just wrapped behind the common ``BaseDetector``
interface so the pipeline can treat it the same as any other backend.
"""
import logging
from typing import List

import cv2
import numpy as np

from .base import BaseDetector, Detection

logger = logging.getLogger(__name__)


class MobileNetSSDDetector(BaseDetector):
    def __init__(self, prototxt_path: str, model_path: str, classes: List[str],
                 confidence_threshold: float = 0.5):
        self.classes = classes
        self.confidence_threshold = confidence_threshold
        logger.info("Loading MobileNet-SSD (Caffe) model...")
        self.net = cv2.dnn.readNetFromCaffe(prototxt_path, model_path)

    def detect(self, frame: np.ndarray) -> List[Detection]:
        blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)), 0.007843, (300, 300), 127.5)
        self.net.setInput(blob)
        raw = self.net.forward()

        detections: List[Detection] = []
        for i in range(raw.shape[2]):
            confidence = float(raw[0, 0, i, 2])
            if confidence <= self.confidence_threshold:
                continue

            class_id = int(raw[0, 0, i, 1])
            if class_id >= len(self.classes):
                continue

            x1, y1, x2, y2 = raw[0, 0, i, 3:7] * np.array(
                [frame.shape[1], frame.shape[0], frame.shape[1], frame.shape[0]]
            )
            detections.append(Detection(
                x1=float(x1), y1=float(y1), x2=float(x2), y2=float(y2),
                confidence=confidence, class_id=class_id, class_name=self.classes[class_id],
            ))
        return detections
