"""YOLOv8 detector (Ultralytics).

Ultralytics is imported lazily inside ``__init__`` so that selecting the
"mobilenet" backend never requires ultralytics/torch to be importable.
"""
import logging
from typing import List

import numpy as np

from .base import BaseDetector, Detection

logger = logging.getLogger(__name__)


class YOLOv8Detector(BaseDetector):
    def __init__(self, weights_path: str = "yolov8n.pt", confidence_threshold: float = 0.5,
                 device: str = "cpu"):
        from ultralytics import YOLO

        logger.info(f"Loading YOLOv8 model from {weights_path}...")
        self.model = YOLO(weights_path)
        self.confidence_threshold = confidence_threshold
        self.device = device

    def detect(self, frame: np.ndarray) -> List[Detection]:
        results = self.model.predict(
            frame, conf=self.confidence_threshold, device=self.device, verbose=False
        )
        result = results[0]
        names = result.names

        detections: List[Detection] = []
        boxes = result.boxes
        if boxes is None:
            return detections

        for box in boxes:
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            confidence = float(box.conf[0])
            class_id = int(box.cls[0])
            detections.append(Detection(
                x1=x1, y1=y1, x2=x2, y2=y2,
                confidence=confidence, class_id=class_id,
                class_name=names.get(class_id, str(class_id)),
            ))
        return detections
