"""Detector backends behind a common interface (see base.Detection / base.BaseDetector)."""
from ..config import Config
from .base import BaseDetector, Detection

__all__ = ["BaseDetector", "Detection", "create_detector"]


def create_detector(config: Config) -> BaseDetector:
    """Build the detector backend selected by ``config.model``.

    Each backend is imported lazily so selecting one model doesn't require the
    other's dependencies to be importable (e.g. picking "mobilenet" shouldn't
    require ultralytics/torch to be installed).
    """
    if config.model == "mobilenet":
        from .mobilenet_ssd import MobileNetSSDDetector
        return MobileNetSSDDetector(
            prototxt_path=config.prototxt_path,
            model_path=config.model_path,
            classes=config.classes,
            confidence_threshold=config.confidence_threshold,
        )

    if config.model == "yolov8":
        from .yolov8 import YOLOv8Detector
        return YOLOv8Detector(
            weights_path=config.yolo_weights,
            confidence_threshold=config.confidence_threshold,
            device=config.device,
        )

    raise ValueError(f"Unknown model: {config.model!r} (expected 'mobilenet' or 'yolov8')")
