"""Common detector interface.

Every backend (MobileNet-SSD, YOLOv8, ...) implements ``detect(frame)`` and
returns a list of ``Detection`` objects in this same shape, so the pipeline
(capture loop, drawing, CSV logging, video output) never needs to know which
model produced them.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List

import numpy as np


@dataclass
class Detection:
    x1: float
    y1: float
    x2: float
    y2: float
    confidence: float
    class_id: int
    class_name: str


class BaseDetector(ABC):
    @abstractmethod
    def detect(self, frame: np.ndarray) -> List[Detection]:
        """Run inference on one BGR frame; return detections already filtered
        by this detector's own confidence threshold."""
        raise NotImplementedError
