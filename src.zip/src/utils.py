"""Small pure helper functions used by the detector.

Kept separate from ``detector.py`` (which needs OpenCV/a loaded network) so
they can be unit tested without a camera, a model file, or a GPU.
"""
from typing import Dict, Tuple

DEFAULT_COLOR: Tuple[int, int, int] = (0, 255, 0)  # green, BGR

COLOR_MAP: Dict[str, Tuple[int, int, int]] = {
    "person": (0, 0, 255),    # red
    "car": (0, 255, 255),     # yellow
    "dog": (255, 0, 0),       # blue
    "cat": (255, 0, 255),     # magenta
}


def get_color(label: str) -> Tuple[int, int, int]:
    """BGR box color for a class label; falls back to green for the rest."""
    return COLOR_MAP.get(label, DEFAULT_COLOR)


def clamp_box(x1: float, y1: float, x2: float, y2: float,
              frame_width: int, frame_height: int) -> Tuple[int, int, int, int]:
    """Clamp a bounding box to the frame so drawing never goes out of bounds."""
    x1 = max(0, int(x1))
    y1 = max(0, int(y1))
    x2 = min(frame_width - 1, int(x2))
    y2 = min(frame_height - 1, int(y2))
    return x1, y1, x2, y2


def is_valid_box(x1: int, y1: int, x2: int, y2: int) -> bool:
    """A box is only worth drawing/logging if it has positive width and height."""
    return x2 > x1 and y2 > y1


def compute_fps(frame_count: int, elapsed_seconds: float) -> float:
    return frame_count / elapsed_seconds if elapsed_seconds > 0 else 0.0
